import { SafeAreaView, View } from 'react-native';

import Routes from './Src/routes/Index';


export default function App() {
  return (
    
    
     <Routes/>
     
  
  );
}
