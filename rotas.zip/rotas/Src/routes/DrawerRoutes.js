import React from 'react';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { Feather } from '@expo/vector-icons';
import TabRoutes from './tabRoutes';
import StackRoutes from './stackRoutes';

const Drawer = createDrawerNavigator();

export default function DrawerRoutes() {
  return (
    <Drawer.Navigator screenOptions={{ title: ' ' }}>
      <Drawer.Screen
        name="home"
        component={TabRoutes}
        options={{
          drawerIcon: ({ color, size }) => <Feather name="home" color={color} size={size} />,
          drawerLabel: 'Início'
        }}
      />
      <Drawer.Screen screenOptions={{ title: ' ' }}
        name="profile"
        component={StackRoutes}
        options={{
          drawerIcon: ({ color, size }) => <Feather name="plus" color={color} size={size} />,
          drawerLabel: 'Perfil'
        }}
      />

      
      <Drawer.Screen screenOptions={{ title: ' ' }}
        name="Feed"
        component={StackRoutes}
        options={{
          drawerIcon: ({ color, size }) => <Feather name="user" color={color} size={size} />,
          drawerLabel: 'Feed'
        }}
      />
    </Drawer.Navigator>
  );
}
