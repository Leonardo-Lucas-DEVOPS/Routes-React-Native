
import { createNativeStackNavigator } from '@react-navigation/native-stack';


import Profile from '../../screen/Profile';

const Stack = createNativeStackNavigator();

export default function StackRoutes() {
  return (
    <Stack.Navigator/*screenOptions={{ HeadersShow : false}} */
                      screenOptions={{ title: ' '}}>
      
        <Stack.Screen name="profile" component={Profile}/>
      
    </Stack.Navigator>
  );
}
